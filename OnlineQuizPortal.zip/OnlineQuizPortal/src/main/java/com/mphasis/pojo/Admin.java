package com.mphasis.pojo;



public class Admin {
	
	
	String aUsername;
	String aPassword;
	public String getaUsername() {
		return aUsername;
	}
	public void setaUsername(String aUsername) {
		this.aUsername = aUsername;
	}
	public String getaPassword() {
		return aPassword;
	}
	public void setaPassword(String aPassword) {
		this.aPassword = aPassword;
	}
	

}
