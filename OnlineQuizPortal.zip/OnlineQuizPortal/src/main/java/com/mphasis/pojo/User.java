package com.mphasis.pojo;





public class User {

	String Uusername;
	String Uname;
	String Upassword;
	public String getUusername() {
		return Uusername;
	}
	public void setUusername(String uusername) {
		Uusername = uusername;
	}
	public String getUname() {
		return Uname;
	}
	public void setUname(String uname) {
		Uname = uname;
	}
	public String getUpassword() {
		return Upassword;
	}
	public void setUpassword(String upassword) {
		Upassword = upassword;
	}

}
