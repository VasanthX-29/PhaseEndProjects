package com.mphasis.servlet;

import java.io.IOException;
import java.sql.SQLException;
import com.mphasis.pojo.*;
import com.mphasis.dao.*;
import com.mphasis.dbJDBC.*;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.mphasis.dao.QuizDAO;
import com.mphasis.pojo.Question;

/**
 * Servlet implementation class EditUserServlet
 */
public class EditUserServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public EditUserServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		User u=new User();
		UserDAO dao=new UserDAO();
		
		//q.setId(Integer.parseInt(request.getParameter("qid")));
		 u.setUname(request.getParameter("uname"));
		u.setUpassword(request.getParameter("pwd"));
		try {
			dao.updateUser(request.getParameter("uid"),u);
		} catch (NumberFormatException | ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		response.sendRedirect("DisplayUsers.jsp");
	}

}
