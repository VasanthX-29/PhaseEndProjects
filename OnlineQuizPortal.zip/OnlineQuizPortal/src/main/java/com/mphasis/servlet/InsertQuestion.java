package com.mphasis.servlet;
import com.mphasis.pojo.*;
import com.mphasis.dao.*;
import com.mphasis.dbJDBC.*;
import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class InsertQuestion
 */
public class InsertQuestion extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public InsertQuestion() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		   Question q=new Question();
		   QuizDAO dao=new QuizDAO();
		   
		   q.setQuizTitle(request.getParameter("qtitle"));
		   q.setCategory(request.getParameter("qcat"));
		   q.setQuestion(request.getParameter("qtext"));
		   q.setOption1(request.getParameter("qopt1"));
		   q.setOption2(request.getParameter("qopt2"));
		   q.setOption3(request.getParameter("qopt3"));
		   q.setOption4(request.getParameter("qopt4"));
		   q.setAnswer(request.getParameter("qans"));
		   
		   try {
			if(dao.addQuestion(q)>0)
			   {
				  response.sendRedirect("AddQuestions.jsp?qtitle="+request.getParameter("qtitle")+"&qcat="+request.getParameter("qcat")); 
			   }
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		  
	}

}
