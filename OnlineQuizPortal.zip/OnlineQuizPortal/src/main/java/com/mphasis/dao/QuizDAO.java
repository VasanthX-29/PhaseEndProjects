package com.mphasis.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.*;

import com.mphasis.dbJDBC.dbJDBC;
import com.mphasis.pojo.Question;

public class QuizDAO {
	
	public int addQuestion(Question q) throws ClassNotFoundException, SQLException
	{
		Connection con=dbJDBC.getConn();
		if(con==null)
		{
			System.out.println("Connection failed");
		}
		else
		{
			System.out.println("Connection successful");
		}
		
		String sql="insert into question(Question, Option1, Option2, Option3, Option4, Answer, QuizTitle, Category) values(?,?,?,?,?,?,?,?)";
		PreparedStatement ps=con.prepareStatement(sql);
		ps.setString(1, q.getQuestion());
		ps.setString(2, q.getOption1());
		ps.setString(3, q.getOption2());
		ps.setString(4, q.getOption3());
		ps.setString(5, q.getOption4());
		ps.setString(6, q.getAnswer());
		ps.setString(7, q.getQuizTitle());
		ps.setString(8, q.getCategory());
		
		return ps.executeUpdate();
		
		
		
	}
	
	public List<Question> displayQuestions() throws SQLException, ClassNotFoundException
	{
		Connection con=dbJDBC.getConn();
		if(con==null)
		{
			System.out.println("Connection failed");
		}
		else
		{
			System.out.println("Connection successful");
		}
		String sql="select *from question";
		PreparedStatement ps=con.prepareStatement(sql);
		ResultSet rs=ps.executeQuery();
		List<Question> list=new ArrayList();
		while(rs.next())
		{
			Question q=new Question();
			q.setId(rs.getInt("Id"));
			q.setQuizTitle(rs.getString("QuizTitle"));
			q.setCategory(rs.getString("Category"));
			q.setQuestion(rs.getString("Question"));
			q.setOption1(rs.getString("Option1"));
			q.setOption2(rs.getString("Option2"));
			q.setOption3(rs.getString("Option3"));
			q.setOption4(rs.getString("Option4"));
			q.setAnswer(rs.getString("Answer"));
			
			list.add(q);
			
			
			}
		
		return list;
		

	}
	
	public Question getQuestionDetails(int qid) throws ClassNotFoundException, SQLException
	{
		Connection con=dbJDBC.getConn();
		Question q=null;
		if(con==null)
		{
			System.out.println("Connection failed");
		}
		else
		{
			System.out.println("Connection successful");
		}
		String sql="select *from question where Id=?";
		PreparedStatement ps=con.prepareStatement(sql);
		ps.setInt(1, qid);
		ResultSet rs=ps.executeQuery();
	
		while(rs.next())
		{
			q=new Question();
			q.setId(rs.getInt("Id"));
			q.setQuizTitle(rs.getString("QuizTitle"));
			q.setCategory(rs.getString("Category"));
			q.setQuestion(rs.getString("Question"));
			q.setOption1(rs.getString("Option1"));
			q.setOption2(rs.getString("Option2"));
			q.setOption3(rs.getString("Option3"));
			q.setOption4(rs.getString("Option4"));
			q.setAnswer(rs.getString("Answer"));
			
		
			
			
			}
		
		return q;
		
	}
	
	public void updateQuestion(int id, Question q) throws SQLException, ClassNotFoundException
	{
		Connection con=dbJDBC.getConn();
		
		if(con==null)
		{
			System.out.println("Connection failed");
		}
		else
		{
			System.out.println("Connection successful");
		}
		String sql="update question set Question=?, Option1=?,Option2=?, Option3=?, Option4=?, Answer=?, QuizTitle=?, Category=? where Id=? ";
		PreparedStatement ps=con.prepareStatement(sql);
		ps.setString(1, q.getQuestion());
		ps.setString(2, q.getOption1());
		ps.setString(3, q.getOption2());
		ps.setString(4, q.getOption3());
		ps.setString(5, q.getOption4());
		ps.setString(6, q.getAnswer());
		ps.setString(7, q.getQuizTitle());
		ps.setString(8, q.getCategory());
		ps.setInt(9, id);
		
		ps.executeUpdate();
		
		ps.close();
	}
	
	public void deleteQuestion(int id) throws ClassNotFoundException, SQLException
	{
		Connection con=dbJDBC.getConn();
		
		if(con==null)
		{
			System.out.println("Connection failed");
		}
		else
		{
			System.out.println("Connection successful");
		}
		String sql="delete from question where Id=?";
		PreparedStatement ps=con.prepareStatement(sql);
		ps.setInt(1, id);
		ps.executeUpdate();
		ps.close();
	}
	
	 public List<String> getQuizTitle() throws SQLException, ClassNotFoundException{
		Connection con=dbJDBC.getConn();
		
		if(con==null)
		{
			System.out.println("Connection failed");
		}
		else
		{
			System.out.println("Connection successful");
		}
		
		String sql="select DISTINCT QuizTitle from question";
		PreparedStatement ps=con.prepareStatement(sql);
		ResultSet rs=ps.executeQuery();
		ArrayList<String> list=new ArrayList<String>();
		while(rs.next())
		{
			list.add(rs.getString("QuizTitle"));
		}
		return list;
		
	}
	
	
	public List<String> getCategory() throws SQLException, ClassNotFoundException{
		Connection con=dbJDBC.getConn();
		
		if(con==null)
		{
			System.out.println("Connection failed");
		}
		else
		{
			System.out.println("Connection successful");
		}
		
		String sql="select DISTINCT Category from question";
		PreparedStatement ps=con.prepareStatement(sql);
		ResultSet rs=ps.executeQuery();
		ArrayList<String> list=new ArrayList<String>();
		while(rs.next())
		{
			list.add(rs.getString("Category"));
		}
		return list;
		
	} 
	
	public List<Question> showCatTit() throws ClassNotFoundException, SQLException
	{
		Connection con=dbJDBC.getConn();
		Question q=null;
		if(con==null)
		{
			System.out.println("Connection failed");
		}
		else
		{
			System.out.println("Connection successful");
		}
		String sql="select Distinct QuizTitle, Category from question";
		PreparedStatement ps=con.prepareStatement(sql);
        List<Question> list=new ArrayList();
		ResultSet rs=ps.executeQuery();
	
		while(rs.next())
		{
			q=new Question();
			q.setQuizTitle(rs.getString("QuizTitle"));
			q.setCategory(rs.getString("Category"));
			
			
		    list.add(q);
			
			
			}
		
		return list;
		
	}
	
	public List<Question> getQuestionsForTest(String title) throws ClassNotFoundException, SQLException
	{
		Connection con=dbJDBC.getConn();
		Question q=null;
		if(con==null)
		{
			System.out.println("Connection failed");
		}
		else
		{
			System.out.println("Connection successful");
		}
		String sql="select *from question where QuizTitle=?";
		PreparedStatement ps=con.prepareStatement(sql);
		ps.setString(1, title);
        List<Question> list=new ArrayList();
		ResultSet rs=ps.executeQuery();
	
		while(rs.next())
		{
			q=new Question();
			q.setCategory(rs.getString("Category"));
			q.setQuizTitle(rs.getString("QuizTitle"));
			q.setQuestion(rs.getString("Question"));
			q.setOption1(rs.getString("Option1"));
			q.setOption2(rs.getString("Option2"));
			q.setOption3(rs.getString("Option3"));
			q.setOption4(rs.getString("Option4"));
			q.setAnswer(rs.getString("Answer"));
			q.setId(rs.getInt("Id"));
			
			
		    list.add(q);
			
			
			}
		
		return list;
		
	}
	
	public List<Question> getOptionsForTest(String title) throws SQLException, ClassNotFoundException{
		Connection con=dbJDBC.getConn();
		Question q=null;
		if(con==null)
		{
			System.out.println("Connection failed");
		}
		else
		{
			System.out.println("Connection successful");
		}
		String sql="select *from question where QuizTitle=?";
		PreparedStatement ps=con.prepareStatement(sql);
		ps.setString(1, title);
        List<Question> list=new ArrayList();
		ResultSet rs=ps.executeQuery();
	
		while(rs.next())
		{
			q=new Question();
			q.setOption1(rs.getString("Option1"));
			q.setOption2(rs.getString("Option2"));
			q.setOption3(rs.getString("Option3"));
			q.setOption4(rs.getString("Option4"));
			
			
		    list.add(q);
			
			
			}
		
		return list;
		
		
		
	}
	
	public void deleteTest(String title) throws SQLException, ClassNotFoundException
	{
		Connection con=dbJDBC.getConn();
		Question q=null;
		if(con==null)
		{
			System.out.println("Connection failed");
		}
		else
		{
			System.out.println("Connection successful");
		}
		String sql="delete from question where QuizTitle=?";
		PreparedStatement ps=con.prepareStatement(sql);
		ps.setString(1, title);
		ps.executeUpdate();
	}

}
