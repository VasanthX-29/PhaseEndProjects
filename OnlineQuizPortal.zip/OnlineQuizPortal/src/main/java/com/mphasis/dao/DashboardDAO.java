package com.mphasis.dao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.mphasis.dbJDBC.dbJDBC;
import com.mphasis.pojo.*;
public class DashboardDAO {
	
	public int insertRecord(DashboardRecord dr) throws SQLException, ClassNotFoundException
	{
		
		Connection con=dbJDBC.getConn();
		if(con==null)
		{
			System.out.println("Connection failed");
		}
		else
		{
			System.out.println("Connection successful");
		}
		
		String sql="insert into dashboard (username, TestMark, TestCategory, TestName) values(?,?,?,?)";
		PreparedStatement ps=con.prepareStatement(sql);
		ps.setString(1, dr.getUsername());
		ps.setInt(2, dr.getMark());
		ps.setString(3, dr.getCategory());
		ps.setString(4, dr.getTitle());
		
		
		return ps.executeUpdate();
		
		
	}
	
	public List<DashboardRecord>displayRecords() throws SQLException, ClassNotFoundException
	{
		Connection con=dbJDBC.getConn();
		if(con==null)
		{
			System.out.println("Connection failed");
		}
		else
		{
			System.out.println("Connection successful");
		}
		String sql="select *from dashboard";
		PreparedStatement ps=con.prepareStatement(sql);
		ResultSet rs=ps.executeQuery();
		List<DashboardRecord> list=new ArrayList();
		while(rs.next())
		{
			DashboardRecord d=new DashboardRecord();
			d.setUsername(rs.getString("username"));
			d.setMark(rs.getInt("TestMark"));
			d.setCategory(rs.getString("TestCategory"));
			d.setTitle(rs.getString("TestName"));
		
			
			list.add(d);
			
			
			}
		
		return list;
		

	}
	
	public List<DashboardRecord> filterRecords(String title, String category) throws ClassNotFoundException, SQLException{
	Connection con=dbJDBC.getConn();
	if(con==null)
	{
		System.out.println("Connection failed");
	}
	else
	{
		System.out.println("Connection successful");
	}
	String sql="select *from dashboard where TestName=? and TestCategory=? order by TestMark desc";
	PreparedStatement ps=con.prepareStatement(sql);
	ps.setString(1, title);
	ps.setString(2, category);
	ResultSet rs=ps.executeQuery();
	List<DashboardRecord> list=new ArrayList();
	while(rs.next())
	{
		DashboardRecord d=new DashboardRecord();
		d.setUsername(rs.getString("username"));
		d.setMark(rs.getInt("TestMark"));
		d.setCategory(rs.getString("TestCategory"));
		d.setTitle(rs.getString("TestName"));
	
		
		list.add(d);
		
		
		}
	
	return list;
	
	
		
	}

}
