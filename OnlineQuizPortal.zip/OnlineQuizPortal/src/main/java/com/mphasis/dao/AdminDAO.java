package com.mphasis.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;



import com.mphasis.dbJDBC.dbJDBC;
import com.mphasis.dbUtil.dbUtil;
import com.mphasis.pojo.Admin;
import com.mphasis.pojo.User;

public class AdminDAO {
	
	
	public boolean checkAdmin(String aName, String aPwd) throws SQLException, ClassNotFoundException
	{

		Connection con=dbJDBC.getConn();
		if(con==null)
		{
			System.out.println("Connection failed");
		}
		else
		{
			System.out.println("Connection successful");
		}
		String sql="select *from admin where aUsername=? and aPassword=?";
		PreparedStatement ps=con.prepareStatement(sql);
		ps.setString(1, aName);
		ps.setString(2, aPwd);
		ResultSet rs=ps.executeQuery();
	    if(rs.next())
	    {
	    	return true;
	    }
	    else
	    {
	    	return false;
	    }
		
	}

}
