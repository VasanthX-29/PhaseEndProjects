package com.mphasis.dao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;



import com.mphasis.dbJDBC.dbJDBC;
import com.mphasis.dbUtil.*;
import com.mphasis.pojo.*;
public class UserDAO {
	
	public int addUser(User user) throws SQLException, ClassNotFoundException
	{
		Connection con=dbJDBC.getConn();
		if(con==null)
		{
			System.out.println("Connection failed");
		}
		else
		{
			System.out.println("Connection successful");
		}
		String sql="insert into user values(?,?,?)";
		PreparedStatement ps=con.prepareStatement(sql);
		ps.setString(1, user.getUusername());
		ps.setString(2, user.getUname());
		ps.setString(3, user.getUpassword());
		return ps.executeUpdate();
	}
	
	public boolean checkUser(String Uusername, String Upassword) throws SQLException, ClassNotFoundException
	{
		
		Connection con=dbJDBC.getConn();
		if(con==null)
		{
			System.out.println("Connection failed");
		}
		else
		{
			System.out.println("Connection successful");
		}
		String sql="select *from user where Uusername=? and Upassword=?";
		PreparedStatement ps=con.prepareStatement(sql);
		ps.setString(1, Uusername);
		ps.setString(2, Upassword);
		ResultSet rs=ps.executeQuery();
	    if(rs.next())
	    {
	    	return true;
	    }
	    else
	    {
	    	return false;
	    }
		
		
	
		
	}
	
	public List<User> displayUsers() throws SQLException, ClassNotFoundException
	{
		Connection con=dbJDBC.getConn();
		if(con==null)
		{
			System.out.println("Connection failed");
		}
		else
		{
			System.out.println("Connection successful");
		}
		String sql="select *from user";
		PreparedStatement ps=con.prepareStatement(sql);
		ResultSet rs=ps.executeQuery();
		List<User> list=new ArrayList();
		while(rs.next())
		{
			User u=new User();
			
			u.setUusername(rs.getString("Uusername"));
			u.setUname(rs.getString("Uname"));
			u.setUpassword(rs.getString("Upassword"));
			
			list.add(u);
			
			
			}
		
		return list;
		

	}
	
	public void  updateUser(String email, User u) throws ClassNotFoundException, SQLException
	{
		Connection con=dbJDBC.getConn();
		
		if(con==null)
		{
			System.out.println("Connection failed");
		}
		else
		{
			System.out.println("Connection successful");
		}
		String sql="update user set Uname=?, Upassword=? where Uusername=? ";
		PreparedStatement ps=con.prepareStatement(sql);
		ps.setString(1, u.getUname());
		ps.setString(2, u.getUpassword());
		ps.setString(3, email);
		
		ps.executeUpdate();
		
		ps.close();
	}
	
	public void deleteUser(String email) throws SQLException, ClassNotFoundException
	{
		Connection con=dbJDBC.getConn();
		
		if(con==null)
		{
			System.out.println("Connection failed");
		}
		else
		{
			System.out.println("Connection successful");
		}
		String sql="delete from user where Uusername=?";
		PreparedStatement ps=con.prepareStatement(sql);
		ps.setString(1, email);
		ps.executeUpdate();
		ps.close();
	}
	
	public User getUser(String email) throws SQLException, ClassNotFoundException
	{
		Connection con=dbJDBC.getConn();
		User u=null;
		if(con==null)
		{
			System.out.println("Connection failed");
		}
		else
		{
			System.out.println("Connection successful");
		}
		String sql="select *from user where Uusername=?";
		PreparedStatement ps=con.prepareStatement(sql);
		ps.setString(1, email);
		ResultSet rs=ps.executeQuery();
	
		while(rs.next())
		{
			u=new User();
			u.setUusername(rs.getString("Uusername"));
			u.setUname(rs.getString("Uname"));
			u.setUpassword(rs.getString("Upassword"));
			
	  }
		
		return u;
		
	}
	
	public void updatePwd(String email, String newpwd) throws SQLException, ClassNotFoundException
	{
       Connection con=dbJDBC.getConn();
		
		if(con==null)
		{
			System.out.println("Connection failed");
		}
		else
		{
			System.out.println("Connection successful");
		}
		String sql="update user set Upassword=? where Uusername=? ";
		PreparedStatement ps=con.prepareStatement(sql);
		ps.setString(1, newpwd);
		ps.setString(2, email);
		
		
		ps.executeUpdate();
		
		ps.close();
	}
	
	

}
